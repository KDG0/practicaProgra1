
package polimorfismo;

public class PeliculaTerror extends Pelicula{
    
    public PeliculaTerror(String titulo, String director, int annio, int duracion, String genero) {
        super(titulo, director, annio, duracion, genero);
    }
    
    @Override
    public void reproducir(){
        System.out.println("Reproduciendo una aterradora escena de terror de " + titulo);
    }
    
    // Método específico para PeliculaTerror
    public void mostrarEscenaIconica(){
        System.out.println("Mostrando una escena icónica de terror con sustos en " + titulo);
    }
}
