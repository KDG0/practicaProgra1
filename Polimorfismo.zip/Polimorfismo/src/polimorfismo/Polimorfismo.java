
package polimorfismo;

public class Polimorfismo {

    public static void main(String[] args) {
        Pelicula peliculaAccion = new PeliculaAccion("Rápidos y Furiosos", "Rob Cohen", 2001, 107, "Acción");
        Pelicula peliculaComedia = new PeliculaComedia("Superbad", "Greg Mottola", 2007, 113, "Comedia");
        Pelicula peliculaTerror = new PeliculaTerror("El Conjuro", "James Wan", 2013, 112, "Terror");

        //Aca usamos Polimorfismo en ya que hacemos uso del metodo general pero con salida especifica.
        peliculaAccion.reproducir();  // Debería imprimir el comportamiento específico de acción
        peliculaComedia.reproducir(); // Debería imprimir el comportamiento específico de comedia
        peliculaTerror.reproducir();  // Debería imprimir el comportamiento específico de terror

        // Llamar a métodos específicos
        ((PeliculaAccion)peliculaAccion).mostrarEscenaAccion();
        ((PeliculaComedia)peliculaComedia).mostrarEscenaDivertida();
        ((PeliculaTerror)peliculaTerror).mostrarEscenaIconica();
    }
    
}
