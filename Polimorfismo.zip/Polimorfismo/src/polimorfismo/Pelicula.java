
package polimorfismo;

public class Pelicula {
    
    protected  String titulo;
    protected String director;
    protected  int annio;
    protected int duracion;
    protected String genero;

    public Pelicula(String titulo, String director, int annio, int duracion, String genero) {
        this.titulo = titulo;
        this.director = director;
        this.annio = annio;
        this.duracion = duracion;
        this.genero = genero;
    }
    
    public void mostrarInfo(){
        System.out.println("Titulo: "+titulo);
        System.out.println("Director: "+director);
        System.out.println("Año: "+annio);
        System.out.println("Duracion: "+duracion);
        System.out.println("Género: "+genero);
        
    }
    
    // Método general que será usado en las subclases como lo son:
    //PeliculaAccion, PeliculaComedia, PeliculaTerror
    public void reproducir(){
        System.out.println("Reproduciendo la película...");
    }
}
