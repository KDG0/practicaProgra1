
package polimorfismo;

public class PeliculaComedia extends Pelicula{
    
    public PeliculaComedia(String titulo, String director, int annio, int duracion, String genero) {
        super(titulo, director, annio, duracion, genero);
    }
    
    @Override
    public void reproducir(){
        System.out.println("Reproduciendo una divertida escena de comedia de " + titulo);
    }
    
    // Método específico para PeliculaComedia
    public void mostrarEscenaDivertida(){
        System.out.println("Mostrando una escena graciosa con chistes en " + titulo);
    }
}
