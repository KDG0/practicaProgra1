
package polimorfismo;


public class PeliculaAccion extends Pelicula{
    
    public PeliculaAccion(String titulo, String director, int annio, int duracion, String genero) {
        super(titulo, director, annio, duracion, genero);
    }
    
    // Sobrescribimos el método para demostrar polimorfismo
    @Override
    public void reproducir(){
        System.out.println("Reproduciendo una emocionante escena de acción de " + titulo);
    }
    
    // Método específico para PeliculaAccion
    public void mostrarEscenaAccion(){
        System.out.println("Mostrando una escena icónica de persecución en " + titulo);
    }
    
}
